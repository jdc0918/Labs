To get started with this Randoop distribution, see the user manual in
doc/index.html or online at https://randoop.github.io/randoop/manual/index.html.
